/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef CHIPMONITOR_H
#define CHIPMONITOR_H
    
// ###################################################### Includes #########################################################
#include "defines.h"
// #########################################################################################################################
    
// ###################################################### Prototypes #######################################################
extern void cymonitoring_get_lastWtd();
// #########################################################################################################################
    
#endif //CHIPMONITOR_H

/* [] END OF FILE */
