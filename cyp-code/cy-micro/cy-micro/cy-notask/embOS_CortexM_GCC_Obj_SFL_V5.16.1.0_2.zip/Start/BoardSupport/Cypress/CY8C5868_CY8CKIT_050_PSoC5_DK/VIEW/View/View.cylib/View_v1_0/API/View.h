/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "cytypes.h"
#include "cyfitter.h"
void `$INSTANCE_NAME`_Start(void);
void `$INSTANCE_NAME`_WriteData(uint8 txData);
void `$INSTANCE_NAME`_tx_isr_SetVector(cyisraddress address);
void `$INSTANCE_NAME`_rx_isr_SetVector(cyisraddress address);

//[] END OF FILE
