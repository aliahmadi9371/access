ReadMe.txt for BSP for ADuCM360 start project.
This project was built for emIDE V2.20.

Supported hardware:
===================
The sample project for the Analog Devices ADuCM360 CPU
is prepared to run on a Analog Devices EVAL-ADuCM360MKZ Rev A board,
but may be used on other target hardware as well.

Configurations
==============
- Debug:
  This configuration is prepared for download into internal
  Flash using J-Link. An embOS debug and profiling library
  is used.

- Release:
  This configuration is prepared for download into internal
  Flash using J-Link. An embOS release library is used.
