ReadMe.txt for the CMSIS generic start project.

This project was built for emIDE V2.20.

Supported hardware:
===================
The sample project for CMSIS should run on any Cortex-M3 core.

Configurations:
===============
- Debug:
  This build configuration is prepared to create an output
  which includes an embOS debug and profiling library.
  To use SEGGER SystemView with this configuration, configure
  SystemViewer for the used target device and interface speed.

- Release:
  This build configuration is prepared to create an output
  which includes an embOS release library.
